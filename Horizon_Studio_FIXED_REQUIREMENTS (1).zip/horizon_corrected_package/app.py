import os, time, uuid, threading, logging, secrets
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
load_dotenv(BASE_DIR / ".env")
DATA_DIR = BASE_DIR / "data"
VIDEO_DIR = BASE_DIR / "generated_videos"
UPLOAD_DIR = BASE_DIR / "uploads"
for p in (DATA_DIR, VIDEO_DIR, UPLOAD_DIR): p.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", f"sqlite:///{DATA_DIR / 'studio.db'}")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 250 * 1024 * 1024
db = SQLAlchemy(app)
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))

ALLOWED_IMAGE_EXT = {"png", "jpg", "jpeg", "webp"}
ALLOWED_VIDEO_EXT = {"mp4", "webm", "mov", "m4v"}
DEFAULT_CREDITS = int(os.environ.get("STARTING_CREDITS", "20"))
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "").strip().lower()
VIDEO_PROVIDER = os.environ.get("VIDEO_PROVIDER", "google").lower()
GOOGLE_MODEL = os.environ.get("GOOGLE_VIDEO_MODEL", "veo-3.1-generate-preview")

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(254), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    credits = db.Column(db.Integer, nullable=False, default=DEFAULT_CREDITS)
    role = db.Column(db.String(20), nullable=False, default="user")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    videos = db.relationship("VideoJob", backref="owner", lazy=True)

class VideoJob(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    prompt = db.Column(db.Text, nullable=False)
    negative_prompt = db.Column(db.Text, default="")
    style = db.Column(db.String(40), default="cinematic")
    aspect_ratio = db.Column(db.String(10), default="16:9")
    duration = db.Column(db.Integer, default=8)
    resolution = db.Column(db.String(10), default="720p")
    status = db.Column(db.String(24), default="queued", nullable=False)
    provider = db.Column(db.String(40), default="google")
    provider_operation = db.Column(db.String(500), default="")
    video_filename = db.Column(db.String(255), default="")
    error_message = db.Column(db.Text, default="")
    credits_charged = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    completed_at = db.Column(db.DateTime)

with app.app_context():
    db.create_all()
    if ADMIN_EMAIL:
        admin = User.query.filter_by(email=ADMIN_EMAIL).first()
        if admin:
            admin.role = "admin"
            db.session.commit()

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            if request.path.startswith("/api/"): return jsonify(error="Please sign in first."), 401
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user or user.role != "admin": abort(403)
        return fn(*args, **kwargs)
    return wrapped

def serialise(job):
    return {"id": job.id, "prompt": job.prompt, "negative_prompt": job.negative_prompt,
            "style": job.style, "aspect_ratio": job.aspect_ratio, "duration": job.duration,
            "resolution": job.resolution, "status": job.status, "error": job.error_message,
            "video_url": url_for("video_file", filename=job.video_filename) if job.video_filename else None,
            "created_at": job.created_at.isoformat(), "credits_charged": job.credits_charged}

def estimate_credits(duration, resolution):
    # Transparent app credits are an internal usage guard, not a claim about provider billing.
    return max(1, int(duration) // 4) * (2 if resolution == "1080p" else 1)

def run_generation(job_id, image_path=None):
    """Background worker. Provider operations are polled without fabricating progress."""
    with app.app_context():
        job = db.session.get(VideoJob, job_id)
        if not job: return
        try:
            if VIDEO_PROVIDER != "google":
                raise RuntimeError(f"Unsupported VIDEO_PROVIDER={VIDEO_PROVIDER!r}. Configure google or implement a provider adapter.")
            api_key = os.environ.get("GOOGLE_API_KEY", "").strip()
            if not api_key:
                raise RuntimeError("Missing GOOGLE_API_KEY. Add your Google AI API key to .env and restart the server.")
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=api_key)
            job.status = "generating"; db.session.commit()
            config = types.GenerateVideosConfig(
                negative_prompt=job.negative_prompt or None,
                aspect_ratio=job.aspect_ratio,
                number_of_videos=1,
            )
            operation = client.models.generate_videos(
                model=GOOGLE_MODEL,
                prompt=job.prompt,
                image=types.Image.from_file(location=image_path) if image_path else None,
                config=config,
            )
            job.provider_operation = getattr(operation, "name", "") or str(operation)
            db.session.commit()
            deadline = time.time() + int(os.environ.get("GENERATION_TIMEOUT_SECONDS", "1800"))
            while not operation.done:
                if time.time() > deadline: raise TimeoutError("Generation timed out while waiting for the provider.")
                time.sleep(10)
                operation = client.operations.get(operation)
                job.provider_operation = getattr(operation, "name", "") or job.provider_operation
                db.session.commit()
            if getattr(operation, "error", None):
                raise RuntimeError(str(operation.error))
            response = getattr(operation, "response", None)
            generated = getattr(response, "generated_videos", None) if response else None
            if not generated:
                raise RuntimeError("Provider completed but returned no generated video.")
            first = generated[0]
            video_obj = getattr(first, "video", None)
            if not video_obj:
                raise RuntimeError("Provider response did not contain a video file.")
            target = VIDEO_DIR / f"{job.id}.mp4"
            client.files.download(file=video_obj, download_path=str(target))
            if not target.exists() or target.stat().st_size == 0:
                raise RuntimeError("The provider download returned an empty file.")
            job.video_filename = target.name
            job.status = "completed"
            job.completed_at = datetime.now(timezone.utc)
            db.session.commit()
        except Exception as exc:
            logging.exception("Video generation failed for job %s", job_id)
            job = db.session.get(VideoJob, job_id)
            if job:
                job.status = "failed"
                job.error_message = str(exc)[:1000]
                # Credits are only deducted after successful completion.
                job.credits_charged = 0
                db.session.commit()
        finally:
            if image_path:
                try: Path(image_path).unlink(missing_ok=True)
                except Exception: pass

@app.context_processor
def inject_globals():
    return {"signed_in_user": current_user(), "provider_configured": bool(os.environ.get("GOOGLE_API_KEY"))}

@app.route("/")
def index():
    user = current_user()
    jobs = VideoJob.query.filter_by(user_id=user.id).order_by(VideoJob.created_at.desc()).limit(6).all() if user else []
    return render_template("index.html", jobs=jobs)

@app.route("/explore")
def explore():
    samples = [
        ("Cinematic", "A lone astronaut walks across a black-sand beach under enormous rings of Saturn, cinematic wide shot, slow tracking camera, dramatic dawn light."),
        ("Nature", "Macro shot of a hummingbird hovering beside vivid flowers in a misty rainforest, delicate wing motion, natural documentary look."),
        ("Anime", "A young explorer rides a glowing train through a floating city above the clouds, hand-painted anime aesthetic, warm sunset."),
        ("Fantasy", "An ancient library opens its doors to a luminous forest, floating books and fireflies, magical cinematic atmosphere."),
        ("Product", "A premium glass perfume bottle rotates slowly on a reflective obsidian surface, soft studio lighting, elegant luxury advertisement."),
        ("Education", "A clear educational animation showing the water cycle: evaporation, condensation, clouds and rainfall, bright 3D classroom style.")
    ]
    return render_template("explore.html", samples=samples)

@app.route("/videos")
@login_required
def videos():
    jobs = VideoJob.query.filter_by(user_id=current_user().id).order_by(VideoJob.created_at.desc()).all()
    return render_template("videos.html", jobs=jobs)

@app.route("/video/<job_id>")
@login_required
def video_detail(job_id):
    job = VideoJob.query.filter_by(id=job_id, user_id=current_user().id).first_or_404()
    return render_template("detail.html", job=job)

@app.route("/settings")
@login_required
def settings():
    return render_template("settings.html", user=current_user())

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if len(email) > 254 or "@" not in email or len(password) < 10:
            flash("Enter a valid email and a password with at least 10 characters.", "error")
        elif User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
        else:
            role = "admin" if ADMIN_EMAIL and email == ADMIN_EMAIL else "user"
            user = User(email=email, password_hash=generate_password_hash(password), credits=DEFAULT_CREDITS, role=role)
            db.session.add(user); db.session.commit()
            session["user_id"] = user.id
            return redirect(url_for("index"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            session.clear(); session["user_id"] = user.id
            return redirect(url_for("index"))
        flash("Email or password is incorrect.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/api/generate", methods=["POST"])
@login_required
def create_generation():
    return jsonify(error="This free-workflow edition does not generate video through a paid API. Use Create to open a free external generator, download your clip, then import it into My Videos."), 410

@app.route("/api/jobs/<job_id>")
@login_required
def job_status(job_id):
    job = VideoJob.query.filter_by(id=job_id, user_id=current_user().id).first_or_404()
    if job.status == "completed" and job.credits_charged == 0:
        cost = estimate_credits(job.duration, job.resolution)
        user = current_user()
        user.credits = max(0, user.credits - cost)
        job.credits_charged = cost
        db.session.commit()
    return jsonify(job=serialise(job), credits=current_user().credits)

@app.route("/api/jobs/<job_id>/rename", methods=["POST"])
@login_required
def rename_job(job_id):
    job = VideoJob.query.filter_by(id=job_id, user_id=current_user().id).first_or_404()
    title = (request.json or {}).get("title", "").strip()
    if not title or len(title) > 100: return jsonify(error="Title must be 1–100 characters."), 400
    # Store title as a prefix in prompt? Keep schema explicit by adding title field in later migrations.
    job.prompt = job.prompt
    return jsonify(message="Renaming is not enabled in this starter build. Original prompts remain preserved."), 501

@app.route("/api/jobs/<job_id>", methods=["DELETE"])
@login_required
def delete_job(job_id):
    job = VideoJob.query.filter_by(id=job_id, user_id=current_user().id).first_or_404()
    if job.video_filename:
        (VIDEO_DIR / job.video_filename).unlink(missing_ok=True)
    db.session.delete(job); db.session.commit()
    return jsonify(ok=True)

@app.route("/library/import", methods=["POST"])
@login_required
def import_video():
    upload = request.files.get("video")
    if not upload or not upload.filename:
        flash("Choose a video file to import.", "error")
        return redirect(url_for("videos"))
    original = secure_filename(upload.filename)
    ext = original.rsplit(".", 1)[-1].lower() if "." in original else ""
    if ext not in ALLOWED_VIDEO_EXT:
        flash("Use an MP4, WEBM, MOV, or M4V video file.", "error")
        return redirect(url_for("videos"))
    filename = f"import-{uuid.uuid4().hex}.{ext}"
    target = VIDEO_DIR / filename
    upload.save(target)
    job = VideoJob(
        user_id=current_user().id,
        prompt=f"Imported video: {original}",
        status="completed",
        provider="local-import",
        video_filename=filename,
        credits_charged=0,
        duration=0,
        resolution="original",
    )
    db.session.add(job)
    db.session.commit()
    flash("Video imported into your private Horizon library.", "success")
    return redirect(url_for("videos"))

@app.route("/video-files/<path:filename>")
@login_required
def video_file(filename):
    job = VideoJob.query.filter_by(video_filename=filename, user_id=current_user().id).first_or_404()
    return send_from_directory(VIDEO_DIR, job.video_filename, as_attachment=False)

@app.route("/download/<job_id>")
@login_required
def download_video(job_id):
    job = VideoJob.query.filter_by(id=job_id, user_id=current_user().id).first_or_404()
    if not job.video_filename: abort(404)
    return send_from_directory(VIDEO_DIR, job.video_filename, as_attachment=True, download_name=f"horizon-{job.id[:8]}{Path(job.video_filename).suffix or '.mp4'}")

@app.route("/admin")
@login_required
@admin_required
def admin():
    jobs = VideoJob.query.order_by(VideoJob.created_at.desc()).limit(100).all()
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin.html", jobs=jobs, users=users)

@app.errorhandler(403)
def forbidden(e): return render_template("error.html", code=403, message="You do not have permission to access this page."), 403
@app.errorhandler(404)
def not_found(e): return render_template("error.html", code=404, message="This page or video was not found."), 404

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
