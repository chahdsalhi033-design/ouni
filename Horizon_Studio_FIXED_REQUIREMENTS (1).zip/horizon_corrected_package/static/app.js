const form=document.getElementById('prompt-form');
if(form){
 const prompt=document.getElementById('prompt');
 const count=document.getElementById('char-count');
 prompt.addEventListener('input',()=>count.textContent=prompt.value.length+' / 2000');
 document.querySelectorAll('.example').forEach(b=>b.addEventListener('click',()=>{prompt.value=b.dataset.prompt;prompt.dispatchEvent(new Event('input'));prompt.focus()}));
 document.getElementById('enhance').addEventListener('click',()=>{
  if(!prompt.value.trim()){prompt.focus();return;}
  const style=document.getElementById('style').value;
  const camera=document.getElementById('camera').value;
  prompt.value=prompt.value.trim()+`, ${style} visual style, ${camera.toLowerCase()} camera movement, coherent motion, detailed lighting, polished composition`;
  prompt.dispatchEvent(new Event('input'));
 });
 form.addEventListener('submit',async e=>{
  e.preventDefault();
  const text=prompt.value.trim();
  if(!text){prompt.focus();return;}
  const finalPrompt=`${text}, ${document.getElementById('style').value} visual style, ${document.getElementById('camera').value.toLowerCase()} camera movement.`;
  const msg=document.getElementById('result-message');
  try{
   await navigator.clipboard.writeText(finalPrompt);
   msg.className='result-message success';
   msg.textContent='Prompt copied. The generator will open in a new tab; paste the prompt there, generate your clip, download it, then import it into My Videos.';
  }catch(_){
   prompt.value=finalPrompt;prompt.focus();prompt.select();
   msg.className='result-message success';
   msg.textContent='Select and copy the prompt shown in the text box, then paste it into the generator that opens.';
  }
  msg.hidden=false;
  window.open(document.getElementById('service').value,'_blank','noopener,noreferrer');
 });
}
