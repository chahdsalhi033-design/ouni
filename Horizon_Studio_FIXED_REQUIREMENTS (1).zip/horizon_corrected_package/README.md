HORIZON AI VIDEO STUDIO — WINDOWS QUICK START

1. In Downloads, right-click Horizon_Studio_CORRECTED.zip.
2. Choose “Extract All…” (French Windows: “Extraire tout…”).
3. Open the extracted folder. START_HORIZON.bat and requirements.txt should be visible together.
4. Double-click START_HORIZON.bat. Do not run it from inside WinRAR.
5. Keep the black window open. The first run needs an internet connection to install Python packages.
6. The browser should open http://127.0.0.1:5000.

If requirements.txt is missing, you are not in the correct extracted folder. Do not move START_HORIZON.bat away from the other files.

Privacy and video generation:
- The app and its library run locally on this computer.
- It does not include a paid API key or make paid API calls by default.
- Horizon organizes prompts and local video files; it does not magically provide unlimited AI video generation. External generators have their own limits and terms.
- Keep the .env file and local database private.
