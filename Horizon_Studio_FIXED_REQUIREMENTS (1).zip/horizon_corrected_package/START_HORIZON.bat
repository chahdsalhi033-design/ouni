@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"
title Horizon AI Video Studio

echo.
echo ==========================================
echo       HORIZON AI VIDEO STUDIO
echo ==========================================
echo.

rem Locate requirements.txt next to this launcher first, then one level below.
set "APPDIR=%ROOT%"
if not exist "%APPDIR%requirements.txt" (
  for /d %%D in ("%ROOT%*") do (
    if exist "%%~fD\requirements.txt" set "APPDIR=%%~fD\"
  )
)
if not exist "%APPDIR%requirements.txt" (
  echo ERROR: requirements.txt was not found.
  echo.
  echo Please extract the NEW ZIP using Windows "Extraire tout...".
  echo Then open the extracted folder and run this BAT from there.
  echo Do NOT run it from inside WinRAR or from the old folder.
  echo.
  echo Expected files: START_HORIZON.bat, requirements.txt, app.py
  pause
  exit /b 1
)
cd /d "%APPDIR%"

echo App folder: %APPDIR%
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found. Install Python 3.10 or newer from python.org.
  echo During installation, enable the Python launcher option.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating the app's private Python environment...
  py -3 -m venv .venv
  if errorlevel 1 (
    echo Could not create the environment. Check that Python is installed correctly.
    pause
    exit /b 1
  )
)

echo Installing/checking app dependencies. The first run may take a few minutes...
"%APPDIR%.venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "%APPDIR%requirements.txt"
if errorlevel 1 (
  echo.
  echo Dependency installation failed. Check your internet connection and the error above.
  pause
  exit /b 1
)

if not exist ".env" (
  copy "%APPDIR%.env.example" "%APPDIR%.env" >nul
  echo Created .env from .env.example.
)

echo.
echo Starting Horizon. Keep this black window open while using the app.
start "" /min cmd /c "timeout /t 4 /nobreak ^>nul ^& start http://127.0.0.1:5000"
"%APPDIR%.venv\Scripts\python.exe" "%APPDIR%app.py"
echo.
echo Horizon has stopped. You can close this window.
pause
